'''
To create new snippets on Jupyter Notebook, run the following line.
Then refresh the page, you'll see then the newly added snippets.
'''
from snippetlib import paste_snippet as ps 
paste_snippets = ps.Paste_Snippet()
