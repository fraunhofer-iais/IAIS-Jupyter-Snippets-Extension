
'''
To upload your python files as snippets on Jupyter Notebook, run the following line.
Then refresh the page, you'll see then the newly added snippets.
'''
from snippetlib import upload_snippet as us
upload_snippets = us.Upload_Snippet()




